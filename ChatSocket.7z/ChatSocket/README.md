# Socket.io Chat App using AngularJS

1) ` bower install `

2) ` npm install `

Running on port: 8080